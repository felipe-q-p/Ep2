#include <iostream>
#include "CircuitoSISO.h"
using namespace std;

CircuitoSISO::CircuitoSISO():Circuito(){
}

CircuitoSISO::~CircuitoSISO(){
    
}


