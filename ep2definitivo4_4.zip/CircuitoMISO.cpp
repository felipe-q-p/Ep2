#include "CircuitoMISO.h"
#include <string>
#include <iostream>
using namespace std;

CircuitoMISO::CircuitoMISO() : Circuito(){
};


CircuitoMISO:: ~CircuitoMISO(){
};

